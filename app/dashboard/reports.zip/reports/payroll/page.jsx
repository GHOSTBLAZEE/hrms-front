"use client";

import PayrollRunsReportPage from "./PayrollRunsReportPage";

export default function Page() {
  return <PayrollRunsReportPage />;
}
