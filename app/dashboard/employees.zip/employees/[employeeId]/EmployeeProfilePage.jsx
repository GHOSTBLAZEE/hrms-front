"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  User,
  Briefcase,
  Phone,
  FileText,
  GraduationCap,
  Users,
  CreditCard,
  Shield,
  TrendingUp,
  Award,
  Calendar,
  Mail,
  MapPin,
  Edit,
  Download,
  MoreVertical,
  AlertCircle,
  CheckCircle,
  Clock,
  Building,
  Landmark,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import apiClient from "@/lib/apiClient";

// Import all tab components
import PersonalInformationTab from "../sections/PersonalInformationTab";
import EmploymentDetailsTab from "../sections/EmploymentDetailsTab";
import ContactInformationTab from "../sections/ContactInformationTab";
import EmergencyContactsTab from "../sections/EmergencyContactsTab";
import IdentificationTab from "../sections/IdentificationTab";
import EducationExperienceTab from "../sections/EducationExperienceTab";
import FamilyDetailsTab from "../sections/FamilyDetailsTab";
import BankingPayrollTab from "../sections/BankingPayrollTab";
import StatutoryComplianceTab from "../sections/StatutoryComplianceTab";
import CareerManagementTab from "../sections/CareerManagementTab";
import DocumentsTab from "../sections/DocumentsTab";
import TrainingDevelopmentTab from "../sections/TrainingDevelopmentTab";

export default function EmployeeProfilePage({ employeeId }) {
  
  const [activeTab, setActiveTab] = useState("personal");
  const [isEditMode, setIsEditMode] = useState(false);

  // Fetch employee data
  const { data: employee, isLoading } = useQuery({
    queryKey: ["employee", employeeId],
    queryFn: async () => {
      const response = await apiClient.get(`/api/v1/employees/${employeeId}`);
      return response.data?.data;
    },
  });


  const getInitials = (name) => {
    if (!name) return "??";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const getStatusConfig = (status) => {
    const configs = {
      active: { label: "Active", variant: "success", icon: CheckCircle },
      probation: { label: "Probation", variant: "warning", icon: Clock },
      inactive: { label: "Inactive", variant: "secondary", icon: AlertCircle },
      terminated: { label: "Terminated", variant: "destructive", icon: AlertCircle },
    };
    return configs[status] || configs.inactive;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Loading employee profile...</p>
        </div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center space-y-4">
          <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto" />
          <p className="text-muted-foreground">Employee not found</p>
        </div>
      </div>
    );
  }
console.log(employee);
  const statusConfig = getStatusConfig(employee.status);
  const StatusIcon = statusConfig.icon;

  const tabsConfig = [
    { id: "personal", label: "Personal Info", icon: User, component: PersonalInformationTab },
    { id: "employment", label: "Employment", icon: Briefcase, component: EmploymentDetailsTab },
    { id: "contact", label: "Contact", icon: Phone, component: ContactInformationTab },
    { id: "emergency", label: "Emergency", icon: AlertCircle, component: EmergencyContactsTab },
    { id: "identification", label: "IDs", icon: FileText, component: IdentificationTab },
    { id: "education", label: "Education", icon: GraduationCap, component: EducationExperienceTab },
    { id: "family", label: "Family", icon: Users, component: FamilyDetailsTab },
    { id: "banking", label: "Banking", icon: CreditCard, component: BankingPayrollTab },
    { id: "statutory", label: "Statutory", icon: Shield, component: StatutoryComplianceTab },
    { id: "career", label: "Career", icon: TrendingUp, component: CareerManagementTab },
    { id: "documents", label: "Documents", icon: FileText, component: DocumentsTab },
    { id: "training", label: "Training", icon: Award, component: TrainingDevelopmentTab },
  ];

  const ActiveTabComponent = tabsConfig.find(t => t.id === activeTab)?.component;

  return (
    <div className="space-y-6 p-6">
      {/* Profile Header */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Avatar Section */}
            <div className="flex flex-col items-center md:items-start gap-4">
              <Avatar className="h-32 w-32 border-4 border-background shadow-lg">
                <AvatarImage src={employee.profile_photo_url} alt={employee.full_name} />
                <AvatarFallback className="text-2xl font-semibold bg-gradient-to-br from-primary to-primary/70 text-primary-foreground">
                  {getInitials(employee.full_name)}
                </AvatarFallback>
              </Avatar>
              <Button variant="outline" size="sm" className="w-full">
                <Edit className="h-4 w-4 mr-2" />
                Update Photo
              </Button>
            </div>

            {/* Main Info */}
            <div className="flex-1 space-y-4">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h1 className="text-3xl font-bold">{employee.full_name}</h1>
                    <Badge variant={statusConfig.variant} className="flex items-center gap-1">
                      <StatusIcon className="h-3 w-3" />
                      {statusConfig.label}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground text-lg">{employee.designation?.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {employee.department?.name} • {employee.location?.name}
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export Profile
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="icon">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit Profile
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Award className="h-4 w-4 mr-2" />
                        Promote
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Building className="h-4 w-4 mr-2" />
                        Transfer
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive">
                        Deactivate Employee
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <User className="h-3 w-3" />
                    Employee ID
                  </p>
                  <p className="font-semibold">{employee.employee_code}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    Joined
                  </p>
                  <p className="font-semibold">
                    {new Date(employee.joined_at).toLocaleDateString()}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Mail className="h-3 w-3" />
                    Email
                  </p>
                  <p className="font-semibold text-sm truncate">{employee.user?.email}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Phone className="h-3 w-3" />
                    Phone
                  </p>
                  <p className="font-semibold">{employee.phone || "Not provided"}</p>
                </div>
              </div>

              {/* Probation Notice */}
              {employee.status === "probation" && employee.probation_end_date && (
                <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 rounded-lg p-3">
                  <div className="flex items-start gap-2">
                    <Clock className="h-4 w-4 text-amber-600 dark:text-amber-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-amber-900 dark:text-amber-100">
                        Probation Period
                      </p>
                      <p className="text-xs text-amber-700 dark:text-amber-300">
                        Ends on {new Date(employee.probation_end_date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs Section */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <div className="overflow-x-auto">
          <TabsList className="inline-flex h-auto flex-wrap gap-1 bg-muted/50 p-1">
            {tabsConfig.map((tab) => {
              const Icon = tab.icon;
              return (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className="flex items-center gap-2 data-[state=active]:bg-background"
                >
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>
        </div>

        {tabsConfig.map((tab) => (
          <TabsContent key={tab.id} value={tab.id} className="space-y-4">
            {ActiveTabComponent && (
              <ActiveTabComponent employee={employee} employeeId={employeeId} />
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}