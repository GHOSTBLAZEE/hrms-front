export default function EmptyState() {
  return (
    <div className="p-10 text-center text-muted-foreground">
      No attendance records available for this month.
    </div>
  );
}
