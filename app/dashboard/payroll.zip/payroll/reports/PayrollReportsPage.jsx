"use client";

import { useState } from "react";
import PayrollReportsTabs from "./components/PayrollReportsTabs";
import PayrollReportFilters from "./components/PayrollReportFilters";
import PayrollSummaryReport from "./components/PayrollSummaryReport";
import DepartmentCostReport from "./components/DepartmentCostReport";
import StatutoryReport from "./components/StatutoryReport";

export default function PayrollReportsPage() {
  const [filters, setFilters] = useState({
    year: new Date().getFullYear(),
    month: new Date().getMonth() + 1,
  });

  const [tab, setTab] = useState("summary");

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold">
          Payroll Reports
        </h1>
        <p className="text-sm text-muted-foreground">
          Finalized payroll analytics & statutory summaries
        </p>
      </header>

      <PayrollReportFilters
        filters={filters}
        onChange={setFilters}
      />

      <PayrollReportsTabs tab={tab} onChange={setTab} />

      {tab === "summary" && (
        <PayrollSummaryReport filters={filters} />
      )}

      {tab === "department" && (
        <DepartmentCostReport filters={filters} />
      )}

      {tab === "statutory" && (
        <StatutoryReport filters={filters} />
      )}
    </div>
  );
}
