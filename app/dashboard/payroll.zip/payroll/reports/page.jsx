"use client";

import PayrollReportsPage from "./PayrollReportsPage";

export default function Page() {
  return <PayrollReportsPage />;
}
