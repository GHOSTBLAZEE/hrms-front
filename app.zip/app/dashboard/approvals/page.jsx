"use client";

import ApprovalsPage from "./ApprovalsPage";

export default function Page() {
  return <ApprovalsPage />;
}
