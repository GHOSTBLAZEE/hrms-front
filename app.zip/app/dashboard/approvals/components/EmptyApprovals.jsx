export default function EmptyApprovals() {
  return (
    <div className="rounded-md border border-dashed p-6 text-sm text-muted-foreground">
      No approvals found.
    </div>
  );
}
