"use client";

import ExportHistoryPage from "./ExportHistoryPage";

export default function Page() {
  return <ExportHistoryPage />;
}
