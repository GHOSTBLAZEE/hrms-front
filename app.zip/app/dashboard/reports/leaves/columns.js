export const columns = [
  { accessorKey: "employee_code", header: "Emp Code" },
  { accessorKey: "employee_name", header: "Employee" },
  { accessorKey: "leave_type", header: "Leave Type" },
  { accessorKey: "used_days", header: "Used" },
  { accessorKey: "remaining_days", header: "Remaining" },
  { accessorKey: "period", header: "Period" },
];
