import LeaveReportsPage from "./LeaveReportsPage";

export default function Page() {
  return <LeaveReportsPage />;
}
