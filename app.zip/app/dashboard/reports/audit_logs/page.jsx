"use client";

import AuditLogsPage from "./AuditLogsPage";

export default function Page() {
  return <AuditLogsPage />;
}
