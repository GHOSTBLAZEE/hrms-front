"use client";

import PayslipsPage from "./PayslipsPage";

export default function Page() {
  return <PayslipsPage />;
}
