export const APPROVAL_MODULES = [
  { key: "leave", label: "Leave Approvals" },
  { key: "attendance", label: "Attendance Corrections" },
  { key: "attendance_unlock", label: "Attendance Unlocks" },
  { key: "transfer", label: "Transfer" },
  { key: "promotion", label: "Promotion" },
];