// app/dashboard/attendance/reports/monthly/page.jsx
"use client";

import MonthlyAttendanceReport from "./MonthlyAttendanceReport";

export default function Page() {
  return <MonthlyAttendanceReport />;
}
