export const columns = [
  {
    accessorKey: "employee.code",
    header: "Emp Code",
  },
  {
    accessorKey: "employee.name",
    header: "Employee",
  },
  {
    accessorKey: "attendance_date",
    header: "Date",
  },
  {
    accessorKey: "status",
    header: "Status",
  },
  {
    accessorKey: "current_step",
    header: "Pending At",
  },
];
